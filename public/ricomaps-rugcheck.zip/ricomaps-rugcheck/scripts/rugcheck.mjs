#!/usr/bin/env node
/**
 * RicoMaps pre-trade rug check.
 *
 * Usage:   node rugcheck.mjs <MINT_ADDRESS> [--json]
 * Env:     RICOMAPS_BASE_URL   (default https://ricomaps.fun)
 *          RICO_API_KEY        (optional; switches to deeper /analyze endpoint)
 *
 * Exit codes (so a bot can branch without parsing stdout):
 *   0  = PASS      20 = BLOCK
 *   10 = CAUTION    1  = ERROR (fail closed — treat as do-not-trade)
 */

const BASE_URL = (process.env.RICOMAPS_BASE_URL || 'https://ricomaps.fun').replace(/\/$/, '');
const API_KEY = process.env.RICO_API_KEY || null;
const SOLANA_ADDR_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;

const EXIT = { PASS: 0, CAUTION: 10, BLOCK: 20, ERROR: 1 };

function fail(message) {
  // Fail closed: any error is a BLOCK-equivalent for an automated gate.
  emit({ verdict: 'BLOCK', reason: message, error: true, reasons: [message] });
  process.exit(EXIT.ERROR);
}

function emit(result) {
  if (process.argv.includes('--json')) {
    console.log(JSON.stringify(result, null, 2));
    return;
  }
  const icon = { BLOCK: '🔴', CAUTION: '🟡', PASS: '🟢' }[result.verdict] || '⚪';
  console.log(`${icon} ${result.verdict}${result.symbol ? `  ${result.symbol}` : ''}`);
  if (result.rugScore != null) console.log(`   rug score: ${result.rugScore}/100 (${result.rugLevel}, ${result.confidence} confidence)`);
  for (const r of result.reasons || []) console.log(`   • ${r}`);
  if (result.coverageNote) console.log(`   ⚠ ${result.coverageNote}`);
}

/** Apply the verdict rules from SKILL.md to a quick-scan/analyze payload. */
function decide(payload) {
  const stats = payload.stats || {};
  const sec = payload.tokenSecurity || {};
  const rug = stats.rugScore || {};
  const bot = stats.botActivityScore || {};
  const meta = payload.tokenMetadata || {};

  const reasons = [];
  let verdict = 'PASS';

  const escalate = (level, reason) => {
    reasons.push(reason);
    if (level === 'BLOCK') verdict = 'BLOCK';
    else if (level === 'CAUTION' && verdict !== 'BLOCK') verdict = 'CAUTION';
  };

  // The detector's rugScore.level already factors in both-authorities AND
  // establishment dampening (a blue-chip like USDC keeps live authorities but
  // is pushed to yellow, not red). So trust `level` as the primary gate and
  // only hard-block on raw both-authorities when the detector itself didn't
  // already clear the token to green — avoids false-flagging established tokens.
  const bothAuthorities = sec.hasMintAuthority && sec.hasFreezeAuthority;

  // --- BLOCK rules ---
  if (rug.level === 'red') escalate('BLOCK', `Rug score is RED (${rug.score}/100)`);
  if (bothAuthorities && rug.level !== 'green')
    escalate('BLOCK', 'Both mint AND freeze authority active — supply inflatable and wallets freezable (honeypot vector)');
  if (bot.level === 'red') escalate('BLOCK', 'Coordinated bot / wash-trading activity detected');

  // --- CAUTION rules (only matter if not already BLOCK) ---
  if (rug.level === 'yellow') escalate('CAUTION', `Rug score is YELLOW (${rug.score}/100)`);
  if (bothAuthorities && rug.level === 'green')
    // Established/green token that still carries both authorities (e.g. a major
    // stablecoin). Not a rug, but the deployer retains control — worth flagging.
    escalate('CAUTION', 'Mint AND freeze authority active (token rated established — deployer still retains control)');
  else if (sec.hasMintAuthority)
    escalate('CAUTION', 'Mint authority active — supply can be inflated');
  else if (sec.hasFreezeAuthority)
    escalate('CAUTION', 'Freeze authority active — wallets can be frozen');
  if ((stats.snipersDetected || 0) > 0)
    escalate('CAUTION', `${stats.snipersDetected} first-block sniper(s) detected`);
  if (Array.isArray(stats.bundledWallets) && stats.bundledWallets.length > 0)
    escalate('CAUTION', `${stats.bundledWallets.length} wallet(s) in Jito bundle clusters`);
  if (rug.confidence === 'low')
    escalate('CAUTION', 'Low holder coverage — risk score is a floor, not a ceiling');

  return {
    verdict,
    symbol: meta.symbol ? `$${meta.symbol}` : null,
    rugScore: rug.score ?? null,
    rugLevel: rug.level ?? 'unknown',
    confidence: rug.confidence ?? 'unknown',
    coverageNote: rug.coverageNote || null,
    reasons: reasons.length ? reasons : ['No critical signals at scanned depth'],
    raw: { rugScore: rug, tokenSecurity: sec, botActivity: bot,
           snipersDetected: stats.snipersDetected, bundledWallets: stats.bundledWallets },
  };
}

async function main() {
  const mint = process.argv[2];
  if (!mint || mint.startsWith('--')) fail('Usage: node rugcheck.mjs <MINT_ADDRESS> [--json]');
  if (!SOLANA_ADDR_RE.test(mint)) fail(`Not a valid Solana mint address: ${mint}`);

  const useAnalyze = !!API_KEY;
  const url = `${BASE_URL}/api/v1/${useAnalyze ? 'analyze' : 'quick-scan'}`;
  const body = useAnalyze ? { mint, apiKey: API_KEY } : { address: mint };

  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(40_000),
    });
  } catch (e) {
    fail(`Network error reaching detector: ${e.message}`);
  }

  if (res.status === 429) fail('Rate limited by detector — back off and retry (cache verdicts per mint)');
  if (!res.ok) fail(`Detector returned HTTP ${res.status}`);

  let payload;
  try { payload = await res.json(); } catch { fail('Detector returned non-JSON'); }
  if (!payload || payload.success === false) fail(payload?.error || 'Scan unsuccessful');

  const result = decide(payload);
  emit(result);
  process.exit(EXIT[result.verdict]);
}

main();
