# RicoMaps Detector API — reference for the rug-check skill

Base URL: `https://ricomaps.fun` (override with `RICOMAPS_BASE_URL`).

## POST /api/v1/quick-scan  (no key, default)

Fast pre-trade scan of the **top ~15 holders**. IP rate-limited.

**Request**
```json
{ "address": "<mint-or-wallet>" }
```

**Response (200)**
```json
{
  "success": true,
  "data": { "nodes": [ ... ], "links": [ ... ] },
  "stats": {
    "rugScore": {
      "level": "green | yellow | red",
      "score": 0,
      "factors": [ { "label": "...", "points": 25, "severity": "critical|high|low" } ],
      "confidence": "high | medium | low",
      "coverageNote": "Low visibility (...) ..."
    },
    "botActivityScore": { "level": "green|yellow|red", "score": 0, "factors": [], "metrics": {} },
    "snipersDetected": 0,
    "sniperWallets": [],
    "bundledWallets": [],
    "supplyConcentration": { },
    "totalHolders": 0,
    "analyzedHolders": 0
  },
  "tokenSecurity": {
    "hasMintAuthority": true,
    "hasFreezeAuthority": true,
    "isMutable": true,
    "riskLevel": "low|medium|high|critical",
    "riskFactors": ["..."]
  },
  "tokenMetadata": { "name": "...", "symbol": "...", "supply": 0, "decimals": 0 }
}
```

**Errors:** `400` invalid address · `429` rate limited (honor `Retry-After`) ·
`500` scan failed. On any non-200 or `success:false`, **fail closed → BLOCK**.

## Rug score thresholds (authoritative)

| level | score | meaning |
|-------|-------|---------|
| green | < 30  | no critical signals |
| yellow| 30–59 | elevated risk |
| red   | ≥ 60  | critical — likely rug/honeypot |

Plus an **auto-red**: when a token has *both* mint and freeze authority active
and is not clearly established (deep LP / size / age), it is forced to `red`
regardless of raw score.

## POST /api/v1/analyze  (API key, deeper)

Top-**30** holders + full cabal mapping. Set `RICO_API_KEY` and the skill's
script auto-switches to this endpoint.

**Request**
```json
{ "apiKey": "YOUR_KEY", "mint": "<mint>" }
```

`apiKey` goes in the **JSON body** (not an Authorization header).
Rate limit: 10 requests/minute per key. Request a key at https://ricomaps.fun.

**Response** adds `summary` (`{ totalHolders, cabalCount, riskScore,
snipersDetected, bundleClustersDetected }`), per-node `identity`/`metadata`,
`creditsUsed`, and `processingMs`. The skill's verdict logic reads the same
`stats`/`tokenSecurity` fields, so both endpoints work identically.

## GET /api/v1/status

Health check → `{ "status": "ok", "version": "1.0.0", "timestamp": "..." }`.
