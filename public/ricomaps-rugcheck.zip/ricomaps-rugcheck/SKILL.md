---
name: ricomaps-rugcheck
description: Use BEFORE buying any Solana token — runs the token mint through the RicoMaps forensic detector (rug score, mint/freeze authority, sniper & Jito-bundle clusters, cabal funders, bot activity, supply concentration) and returns a BLOCK / CAUTION / PASS verdict so a trading agent can decide whether to trade. Trigger on "should I buy", "is this token safe", "rug check", "check this CA", "scan before trade", or any pre-trade safety gate on a Solana mint address.
user-invocable: true
license: MIT
metadata:
  author: RicoMaps
  version: 1.0.0
  homepage: https://ricomaps.fun
---

# RicoMaps Rug Check (pre-trade safety gate)

Run any Solana token mint through the RicoMaps forensic detector and get a
machine-readable **BLOCK / CAUTION / PASS** verdict *before* a trade executes.

This skill is built for **trading agents**: call it as the first step in a buy
flow. If the verdict is `BLOCK`, the agent should refuse the trade.

## When to use this

Invoke whenever an agent (or user) is about to buy a Solana SPL token and wants
a safety check first. Typical triggers:

- "Should I buy `<mint>`?" / "Is `<mint>` safe?"
- "Rug check `<mint>`" / "Scan this CA before I ape"
- Any automated pre-trade gate in a Solana trading bot

**Input:** a Solana token mint (base58, 32–44 chars).
**Output:** verdict + the risk factors that drove it.

## How to run it

The detector is a public REST endpoint — **no API key required**. The skill
ships a script that calls it and prints a structured verdict.

```bash
# from the skill directory
node scripts/rugcheck.mjs <MINT_ADDRESS>

# or point at a self-hosted / custom instance
RICOMAPS_BASE_URL=https://ricomaps.fun node scripts/rugcheck.mjs <MINT_ADDRESS>
```

The script exits with code `0` on PASS, `10` on CAUTION, `20` on BLOCK, and
`1` on error — so a bot can branch on the exit code without parsing JSON.

If you can't run Node, call the endpoint directly:

```bash
curl -s -X POST https://ricomaps.fun/api/v1/quick-scan \
  -H "Content-Type: application/json" \
  -d '{"address":"<MINT_ADDRESS>"}'
```

## The verdict (how to act)

Map the detector output to one of three actions. **Default to caution: if the
scan fails or returns `success:false`, treat it as `BLOCK` (fail closed).**

| Verdict | Meaning | Agent action |
|---------|---------|--------------|
| **BLOCK** 🔴 | Critical risk. Likely rug / honeypot / coordinated dump. | **Refuse the trade.** |
| **CAUTION** 🟡 | Elevated risk. Tradeable only with tight size / stop. | Warn, require explicit override, reduce size. |
| **PASS** 🟢 | No critical signals at the scanned depth. | OK to proceed (still not financial advice). |

### Verdict rules (in priority order)

A token is **BLOCK** if ANY of:
- `stats.rugScore.level === "red"` (rug score ≥ 60, or both mint + freeze
  authority active on a non-established token = automatic red)
- `tokenSecurity.hasFreezeAuthority === true` **and** `tokenSecurity.hasMintAuthority === true`,
  **unless** the detector already rated it `green` (its establishment dampening
  cleared a blue-chip like a major stablecoin — those drop to CAUTION instead)
- `stats.botActivityScore.level === "red"` (coordinated bot / wash activity)

A token is **CAUTION** if not BLOCK and ANY of:
- `stats.rugScore.level === "yellow"` (rug score 30–59)
- `tokenSecurity.hasMintAuthority === true` (supply can be inflated) — alone
- `tokenSecurity.hasFreezeAuthority === true` (wallets can be frozen) — alone
- `stats.snipersDetected > 0` or bundle clusters present
- `stats.rugScore.confidence === "low"` (see coverage caveat below)

Otherwise **PASS**.

> These thresholds are sane defaults, not gospel. A bot can tighten them (e.g.
> treat any `yellow` as BLOCK) by editing `scripts/rugcheck.mjs`.

## Reading the detector output

Key fields from `/api/v1/quick-scan` (full reference in `reference/api.md`):

- `stats.rugScore` → `{ level: "green"|"yellow"|"red", score: 0–100, factors[], confidence, coverageNote }`
  The headline risk number. Thresholds: **red ≥ 60, yellow ≥ 30, green < 30.**
- `tokenSecurity` → `{ hasMintAuthority, hasFreezeAuthority, isMutable, riskLevel }`
  On-chain authorities. Active mint = inflatable supply; active freeze = the
  deployer can lock your wallet (honeypot vector).
- `stats.botActivityScore` → coordinated bot / wash-trading signal.
- `stats.snipersDetected`, `stats.bundledWallets` → first-block snipers and
  Jito-bundle clusters (coordinated launch).
- `stats.supplyConcentration` → how concentrated the holdings are.

### ⚠️ Coverage caveat — do not ignore

Quick-scan inspects the **top ~15 holders**. On a freshly graduated token this
can be a small fraction of supply. When `rugScore.confidence === "low"` or
`coverageNote` is present, **the risk score is a floor, not a ceiling** —
concentration may be understated. A `green` with low confidence is *not* a
clean bill of health. Surface this to the user; for automated gates, treat low
confidence as at least CAUTION.

For deeper coverage (top-30 holders, full cabal mapping) use the authenticated
`/api/v1/analyze` endpoint with a RicoMaps API key — see `reference/api.md`.

## What this does NOT do

- It does not place, sign, or cancel trades. It only **reports**.
- It is not financial advice. A PASS means "no critical on-chain red flags at
  the scanned depth," not "this will go up."
- It can't see off-chain risk (team, locked LP claims, social manipulation).

## Limits

- Public endpoint is **IP rate-limited**. Cache a verdict for a few minutes per
  mint instead of re-scanning on every tick.
- New tokens with thin holder data return low-confidence scores — see caveat.
